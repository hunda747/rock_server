const oddsTable = {
  1: { 1: 4 },
  2: [{ 1: 0 }, { 2: 15 }],
  3: [{ 1: 0 }, { 2: 3 }, { 3: 35 }],
  4: [{ 1: 0 }, { 2: 1 }, { 3: 8 }, { 4: 100 }],
  // Add more entries for higher selections if needed
};

module.exports = oddsTable;
